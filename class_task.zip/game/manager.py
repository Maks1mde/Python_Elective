class GameManager:

    def __init__(self, min_range, max_range, max_steps):
        self.min_range = min_range
        self.max_range = max_range
        self.max_steps = max_steps
        self.players = []
        self.current_step = 0
        self.winner = None

    def add_player(self, player):
        self.players.append(player)