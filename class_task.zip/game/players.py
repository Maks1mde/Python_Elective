import random

class Player:

    def __init__(self, name):
        print("Игрок с именем {} создан".format(name))
        self.name = name
        self.guessed_number = None

    def guess_number(self, min_range, max_range):
        self.guessed_number = int(input(f"Загадайте число от {min_range} до {max_range}: "))

    def make_guess(self, min_range, max_range):
        guess = int(input(f"Введите число от {min_range} до {max_range}: "))
        return guess


class DichotomyPlayer:

    def __init__(self, name):
        print("Бот с именем {} создан".format(name))
        name += " (Дихотомия)"
        self.name = name
        self.max_possible_number = None
        self.min_possible_number = None
        self.guessed_number = None
        self.last_guess = None

    def guess_number(self, min_range, max_range):
        guessed_number = random.randint(min_range, max_range)
        return guessed_number

    def make_guess(self, min_range, max_range):
        if not self.min_possible_number:
            self.min_possible_number = min_range
            self.max_possible_number = max_range
        guess = (min_range + max_range) // 2
        self.last_guess = guess
        return guess


class SequentialPlayer:

    def __init__(self, name):
        print("Бот с именем {} создан".format(name))
        name += " (Последовательно)"
        self.name = name
        self.guesses = None
        self.guessed_number = None

    def guess_number(self, min_range, max_range):
        guessed_number = random.randint(min_range, max_range)
        return guessed_number

    def make_guess(self, min_range, max_range):
        if not self.guesses:
            guess = min_range
        else:
            guess = self.guesses + 1

        self.guesses[0] += 1
        return guess


class RandomPlayer:

    def __init__(self, name):
        print("Бот с именем {} создан".format(name))
        name += " (Random)"
        self.name = name
        self.guesses = []
        self.guessed_number = None

    def guess_number(self, min_range, max_range):
        guessed_number = random.randint(min_range, max_range)
        return guessed_number

    def make_guess(self, min_range, max_range):
        flag = True
        while flag:
            flag = False
            guess = random.randint(min_range, max_range)
            for last_guesses in self.guesses:
                if last_guesses == guess:
                    flag = True

        self.guesses.append(guess)
        return guess
