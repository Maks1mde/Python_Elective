if __name__ == '__main__':

    print("Program is started \n")

    max_range = int(input())
    min_range = int(input())
    max_steps = int(input())

    print("Program is finished \n")
