import random


# ЗАДАНИЕ 1
def print_table(lst, sign):
    for i in range(9):
        for j in range(9):
            if lst[i][j] % 1:
                result_str = f"{j + 1}{sign}{i + 1}={lst[i][j]:.2f}"
            else:
                result_str = f"{j + 1}{sign}{i + 1}={int(lst[i][j])}"
            print(f'{result_str:<9}', end=" ")
        print()


def show_tables():
    print("Выберите таблицу:")
    print("1 - Умножение")
    print("2 - Деление")
    print("3 - Вычитание")
    print("4 - Сложение")

    choice_sign = int(input("Ваш выбор: "))
    lst = []
    x = None
    sign = None
    for i in range(9):
        a = []
        for j in range(9):
            if choice_sign == 1:
                x = (i + 1) * (j + 1)
                sign = "*"
            elif choice_sign == 2:
                x = (i + 1) / (j + 1)
                sign = "/"
            elif choice_sign == 3:
                x = (i + 1) - (j + 1)
                sign = "-"
            elif choice_sign == 4:
                x = (i + 1) + (j + 1)
                sign = "+"
            a.append(x)
        lst.append(a)
    print_table(lst, sign)


# ЗАДАНИЕ 2
def create_vector(n):
    return [random.random() for _ in range(n)]


def create_matrix(m, n):
    return [[random.random() for _ in range(n)] for _ in range(m)]


def create_image(m, n):
    return [[[random.random() for _ in range(3)] for _ in range(n)] for _ in range(m)]


def print_image(image):
    print()
    for i, row in enumerate(image):
        for pixel in row:
            formatted_pixel = "[" + " ".join(f"{ch:8.4f}" for ch in pixel) + "]"
            print(formatted_pixel, end=" ")
        print()
    print()


def print_matrix(matrix):
    print()
    for row in matrix:
        print(" ".join(f"{x:8.4f}" for x in row))
    print()


def print_vector(vector):
    print()
    print(" ".join(f"{x:8.4f}" for x in vector))
    print()


def matrix_vector_multiply(matrix, vector):
    if len(matrix[0]) != len(vector):
        raise ValueError("Размеры матрицы и вектора не совместимы")

    result = []
    for i in range(len(matrix)):
        sum_val = 0
        for j in range(len(vector)):
            sum_val += matrix[i][j] * vector[j]
        result.append(sum_val)
    print_vector(result)


def diagonal_sum(matrix):
    if len(matrix) != len(matrix[0]):
        raise ValueError("Матрица должна быть квадратной")

    total = 0
    for i in range(len(matrix)):
        total += matrix[i][i]
    return total


def convolution_2d(image, kernel):
    image_height = len(image)
    image_width = len(image[0])
    kernel_height = len(kernel)
    kernel_width = len(kernel[0])

    result_height = image_height - kernel_height + 1
    result_width = image_width - kernel_width + 1

    result = [[0.0 for _ in range(result_width)] for _ in range(result_height)]
    if kernel_height <= image_height or kernel_width <= image_width:
        for i in range(result_height):
            for j in range(result_width):
                sum_val = 0
                for ki in range(kernel_height):
                    for kj in range(kernel_width):
                        sum_val += image[i + ki][j + kj] * kernel[ki][kj]
                result[i][j] = sum_val

        return result
    else:
        raise ValueError("Размерность ядра свертки превышает размерность матрицы")


def function_realize():
    vector = None
    matrix = None

    while True:
        print("Выберите задание:")
        print("1 - Создать вектор")
        print("2 - Создать матрицу")
        print("3 - Умножение матрицы на вектор")
        print("4 - Печать матрицы")
        print("5 - Печать вектора")
        print("6 - Сумма диагональных элементов матрицы")
        print("7 - Двумерную свертка изображения")
        print("0 - Выход")

        choice_func = int(input("Ваш выбор: "))
        match choice_func:
            case 0:
                break
            case 1:
                print("Задайте размерность вектора")
                n = int(input("N: "))
                vector = create_vector(n)
            case 2:
                print("Задайте размерность матрицы")
                m = int(input("M: "))
                n = int(input("N: "))
                matrix = create_matrix(m, n)
            case 3:
                if matrix and vector:
                    matrix_vector_multiply(matrix, vector)
            case 4:
                print_matrix(matrix)
            case 5:
                print_vector(vector)
            case 6:
                print()
                print(diagonal_sum(matrix))
                print()
            case 7:
                print("Задайте размерность матрицы ядра")
                m = int(input("M: "))
                n = int(input("N: "))
                matrix1 = create_matrix(m, n)
                print(convolution_2d(matrix, matrix1))
            case _:
                pass


# ЗАДАНИЕ 3
def multichannel_filter(convolution_func):

    def wrapper(image, kernel):
        if isinstance(image[0][0], (list, tuple)):
            channels = len(image[0][0])
            result_channels = []

            for channel in range(channels):
                single_channel = [[pixel[channel] for pixel in row] for row in image]
                filtered_channel = convolution_func(single_channel, kernel)
                result_channels.append(filtered_channel)

            result_height = len(result_channels[0])
            result_width = len(result_channels[0][0])
            result = [[[0.0 for _ in range(channels)] for _ in range(result_width)]
                      for _ in range(result_height)]

            for i in range(result_height):
                for j in range(result_width):
                    for channel in range(channels):
                        result[i][j][channel] = result_channels[channel][i][j]

            return result
        else:
            return convolution_func(image, kernel)

    return wrapper


@multichannel_filter
def convolution_2d_decorated(image, kernel):
    return convolution_2d(image, kernel)


def function_with_image():
    print("Задайте размерность многоканального изображения")
    m = int(input("M: "))
    n = int(input("N: "))
    multichannel_image = create_image(m, n)

    print("Задайте размерность ядра свертки")
    m = int(input("M: "))
    n = int(input("N: "))
    kernel = create_matrix(m, n)

    print("Многоканальное изображение:")
    print_image(multichannel_image)

    print("Ядро свертки:")
    print_matrix(kernel)

    multichannel_result = convolution_2d_decorated(multichannel_image, kernel)
    print("Результат многоканальной свертки:")
    print_image(multichannel_result)


# ЗАДАНИЕ 4
def rgb_to_yiq(r_color, g_color, b_color):
    y_color = 0.299 * r_color + 0.587 * g_color + 0.114 * b_color
    i_color = 0.596 * r_color - 0.274 * g_color - 0.322 * b_color
    q_color = 0.211 * r_color - 0.523 * g_color + 0.312 * b_color
    return y_color, i_color, q_color


def yiq_to_rgb(y_color, i_color, q_color):
    r_color = y_color + 0.956 * i_color + 0.621 * q_color
    g_color = y_color - 0.272 * i_color - 0.647 * q_color
    b_color = y_color - 1.106 * i_color + 1.703 * q_color
    return r_color, g_color, b_color


def convert_pixel_color(pixel):
    c1, c2, c3, color_type = pixel

    if color_type == 0:
        y_color, i_color, q_color = rgb_to_yiq(c1, c2, c3)
        return [y_color, i_color, q_color, 1]
    elif color_type == 1:
        r_color, g_color, b_color = yiq_to_rgb(c1, c2, c3)
        return [r_color, g_color, b_color, 0]
    else:
        raise ValueError("Неизвестный тип цвета. Допустимые значения: 0 (RGB) или 1 (YIQ)")


def convert_image_to_other_color():
    print("Задайте размерность изображения")
    m = int(input("M: "))
    n = int(input("N: "))
    image = create_image(m, n)

    print("0 - RGB")
    print("1 - YIQ")
    color_type = int(input("Задайте цвет: "))

    for row in image:
        for pixel in row:
            pixel.append(color_type)

    print("Исходное изображение:")
    print_image(image)

    result = []
    for row in image:
        result_row = []
        for pixel in row:
            result_row.append(convert_pixel_color(pixel))
        result.append(result_row)

    print("Результат:")
    print_image(result)


if __name__ == "__main__":
    print("Выберите задание:")
    print("1 - Вывод на экран таблицы")
    print("2 - Функции")
    print("3 - Обработка изображений")
    print("4 - Функция автоматического конвертирования")

    choice = int(input("Ваш выбор: "))
    match choice:
        case 1:
            show_tables()
        case 2:
            function_realize()
        case 3:
            function_with_image()
        case 4:
            convert_image_to_other_color()
