"""
Часть 1. Главная программа
"""

import random
from module import *


def gen_random_matrix(m, n, min_val=0, max_val=100):
    return [[random.randint(min_val, max_val) for _ in range(n)] for _ in range(m)]


def gen_random_vector(n, min_val=0, max_val=100):
    return [random.randint(min_val, max_val) for _ in range(n)]


def print_matrix(matrix):
    print()
    for row in matrix:
        for num in row:
            print(num, end=" ")
        print()


def print_vector(vector):
    print()
    for num in vector:
        print(num, end=" ")


task_times = []

print("\nЗадание 1.1")
matrix_a = gen_random_matrix(3, 3, 1, 10)
print_matrix(matrix_a)
matrix_b = gen_random_matrix(3, 3, 1, 10)
print_matrix(matrix_b)

result, elapsed = measure_time(matrix_matrix_multiply, matrix_a, matrix_b)
print("\nРезультат:")
print_matrix(result)
task_times.append(elapsed * 1000)
print(f"Время: {elapsed * 1000} мс")

print("\nЗадание 1.2")
matrix = gen_random_matrix(3, 3, 1, 10)
print_matrix(matrix)
vector = gen_random_vector(3, 1, 10)
print_vector(vector)

result, elapsed = measure_time(matrix_vector_multiply, matrix, vector)
print("\nРезультат:")
print_vector(result)
task_times.append(elapsed * 1000)
print(f"Время: {elapsed * 1000} мс")

print("\nЗадание 1.3")
matrix = gen_random_matrix(3, 3, 1, 10)
print_matrix(matrix)

result, elapsed = measure_time(matrix_trace, matrix)
print("\nРезультат:")
print(result)
task_times.append(elapsed * 1000)
print(f"Время: {elapsed * 1000} мс")

print("\nЗадание 1.4")
vector_a = gen_random_vector(3, 1, 10)
print_vector(vector_a)
vector_b = gen_random_vector(3, 1, 10)
print_vector(vector_b)

result, elapsed = measure_time(vector_vector_scalar_multiply, vector_a, vector_b)
print("\nРезультат:")
print(result)
task_times.append(elapsed * 1000)
print(f"Время: {elapsed * 1000} мс")

print("\nЗадание 1.5")
vector = gen_random_vector(10, 0, 100)
print_vector(vector)

result, elapsed = measure_time(gistogram, vector, 2)
print("\nРезультат:")
print_vector(result)
task_times.append(elapsed * 1000)
print(f"Время: {elapsed * 1000} мс")

print("\nЗадание 1.6")
filter = [-1, 0, 1]
sizes_filter = [100, 1000, 10000]

vector = gen_random_vector(10, 0, 100)
print_vector(vector)
print_vector(filter)

result, elapsed = measure_time(vector_filter, vector, filter)
print_vector(result)
task_times.append(elapsed * 1000)
print(f"Время: {elapsed * 1000} мс")

print("\nЗадание 1.7")
write_to_file("times.json", f"{task_times} мс")

result = read_from_file("test.json")
print("\nЗагруженный результат:")
print_vector(result)
