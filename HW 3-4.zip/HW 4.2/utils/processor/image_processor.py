import cv2
import numpy as np

def compute_histogram(image, bins=256):
    histogram = cv2.calcHist([image], [0], None, [bins], [0, 256])
    return histogram.flatten()



def histogram_equalization(image):
    height, width = image.shape
    pixel_count = height * width

    hist = compute_histogram(image)

    cdf = []
    sum_ = 0
    for freq in hist:
        sum_ += freq
        cdf.append(sum_)

    cdf_min = min(v for v in cdf if v > 0)

    lookup = [0] * 256
    for i in range(256):
        if pixel_count > cdf_min:
            normalized = (cdf[i] - cdf_min) / (pixel_count - cdf_min)
            lookup[i] = int(normalized * 255)
        else:
            lookup[i] = i
    
    lookup = np.array(lookup, dtype=np.uint8)
    equalized = lookup[image.flatten()].astype(np.uint8)
    equalized = equalized.reshape(image.shape)

    return equalized

def gamma_correction(image, gamma=1.0):
    if gamma == 1.0:
        return image.copy()

    inv_gamma = 1.0 / gamma
    lookup = np.array([((i / 255.0) ** inv_gamma) * 255 for i in range(256)], dtype=np.uint8)
    corrected = lookup[image]

    return corrected